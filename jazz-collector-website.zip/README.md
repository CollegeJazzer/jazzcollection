# CollegeJazzer's Collection

A simple static jazz collection website with links for Video, Audio, and MP3 artist lists.

## Files

- `index.html` — homepage
- `video.html` — video artists
- `audio.html` — audio artists
- `mp3.html` — MP3 artists
- `styles.css` — styling for the site

## Publish

1. Commit the files:

```bash
git add .
git commit -m "Add CollegeJazzer static site"
```

2. Push to GitHub:

```bash
git push origin main
```

3. Enable GitHub Pages in the repository settings:

- Go to `Settings` > `Pages`
- Choose `main` branch and `/ (root)` folder
- Save and note the published URL

Then the site will be available at the GitHub Pages URL.
